import React, { useState } from "react";
import "./styles.css";

const App = () => {
  const [users, setUsers] = useState([]);

  const loadUsers = async () => {
    //console.log('before');
    const response = await fetch("https://api.github.com/users");
    const jsonResponse = await response.json();
    setUsers(jsonResponse);
  };
  return (
    <div className="App">
      <h4>Click on Get Data...</h4>
      <button className="btn" onClick={loadUsers}>
        Get Data
      </button>
      <h2>Hello All,</h2>
      <h3>Users:</h3>
      <ul className="grid-container">
        {users.map(({ id, login, url, type }) => (
          <li key={id}>
            {" "}
            Id: {id} Name: {login}
            URL: {url} Type: {type}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default App;
